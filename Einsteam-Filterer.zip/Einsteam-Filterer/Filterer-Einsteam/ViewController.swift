//
//  ViewController.swift
//  Filterer-Einsteam
//
//  Created by Romit Bhatia on 4/23/16.
//  Copyright © 2016 Einsteam. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet var imageView: UIImageView!
    @IBOutlet var filteredImage: UIImageView!
    @IBOutlet var originalLabel: UIView!
    @IBOutlet var secondaryMenu: UIView!
    @IBOutlet var bottomMenu: UIView!
    
    var avgRed = 0
    var avgGreen = 0
    var avgBlue = 0
    var sliderValue = 5
    var redImage : UIImage?
    var greenImage : UIImage?
    var blueImage : UIImage?
    
    @IBOutlet var sliderMenu: UIView!
    
    @IBOutlet var NewPhoto: UIButton!
    @IBAction func onNewPhoto(sender: AnyObject) {
        let actionSheet = UIAlertController(title: "New Photo", message: nil, preferredStyle: .ActionSheet)
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .Default, handler: { action in
            self.showCamera()
        }))
        actionSheet.addAction(UIAlertAction(title: "Album", style: .Default, handler: { action in
            self.showAlbum()
        }))
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .Cancel, handler: nil))
        self.presentViewController(actionSheet, animated: true, completion: nil)
    }
    func showCamera() {
        let cameraPicker = UIImagePickerController()
        cameraPicker.delegate = self
        cameraPicker.sourceType = .Camera
        presentViewController(cameraPicker, animated: true, completion: nil)
    }
    func showAlbum() {
        let cameraPicker = UIImagePickerController()
        cameraPicker.delegate = self
        cameraPicker.sourceType = .PhotoLibrary
        presentViewController(cameraPicker, animated: true, completion: nil)
    }
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        dismissViewControllerAnimated(true, completion: nil)
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage {
            imageView.image = image
            imageView.alpha = 1.0
            filteredImage.alpha = 0.0
            originalLabel.alpha = 1.0
            buttonEdit.enabled = false
            hideSliderMenu()
            filterButton.selected = false
            hideSecondaryMenu()
            Compare.enabled = false
            //avgColor(image)
        }
    }
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBOutlet var filterButton: UIButton!
    @IBAction func onFilter(sender: UIButton) {
        if (sender.selected) {
            hideSecondaryMenu()
            sender.selected = false
        } else {
            if buttonEdit.selected {
                buttonEdit.selected = false
                hideSliderMenu()
            }
            showSecondaryMenu()
            let image = UIImage(named: "filter1")! as UIImage
            buttonOriginal.setBackgroundImage(image, forState: .Normal)
            let filterImage = redConversion(image)
            RedFilter.setBackgroundImage(filterImage, forState: .Normal)
            let filterImage1 = greenConversion(image)
            GreenFilter.setBackgroundImage(filterImage1, forState: .Normal)
            let filterImage2 = blueConversion(image)
            BlueFilter.setBackgroundImage(filterImage2, forState: .Normal)
            sender.selected = true
            Compare.selected = false
        }
    }
    func showSecondaryMenu() {
        view.addSubview(secondaryMenu)
        let bottomConstraint = secondaryMenu.bottomAnchor.constraintEqualToAnchor(bottomMenu.topAnchor)
        let leftConstraint = secondaryMenu.leftAnchor.constraintEqualToAnchor(view.leftAnchor)
        let rightConstraint = secondaryMenu.rightAnchor.constraintEqualToAnchor(view.rightAnchor)
        let heightConstraint = secondaryMenu.heightAnchor.constraintEqualToConstant(44)
        NSLayoutConstraint.activateConstraints([bottomConstraint,leftConstraint,rightConstraint,heightConstraint])
        view.layoutIfNeeded()
        self.secondaryMenu.alpha = 0
        UIView.animateWithDuration(0.4) {
            self.secondaryMenu.alpha = 1.0
        }
    }
    func hideSecondaryMenu() {
        UIView.animateWithDuration(0.4, animations: {
            self.secondaryMenu.alpha = 0
            }) { completed in
                if completed == true {
                    self.secondaryMenu.removeFromSuperview()
                }
        }
    }
    
    @IBOutlet var buttonEdit: UIButton!
    @IBAction func onEditButton(sender: UIButton) {
        if buttonEdit.selected {
            hideSliderMenu()
            buttonEdit.selected = false
        } else {
            if filterButton.selected {
                filterButton.selected = false
                hideSecondaryMenu()
            }
            showSliderMenu()
            buttonEdit.selected = true
            Compare.selected = false
        }
    }
    func showSliderMenu() {
        view.addSubview(sliderMenu)
        let bottomConstraint = sliderMenu.bottomAnchor.constraintEqualToAnchor(bottomMenu.topAnchor)
        let leftConstraint = sliderMenu.leftAnchor.constraintEqualToAnchor(view.leftAnchor)
        let rightConstraint = sliderMenu.rightAnchor.constraintEqualToAnchor(view.rightAnchor)
        let heightConstraint = sliderMenu.heightAnchor.constraintEqualToConstant(44)
        NSLayoutConstraint.activateConstraints([bottomConstraint,leftConstraint,rightConstraint,heightConstraint])
        view.layoutIfNeeded()
        self.sliderMenu.alpha = 0
        UIView.animateWithDuration(0.4) {
            self.sliderMenu.alpha = 1.0
        }
    }
    func hideSliderMenu() {
        UIView.animateWithDuration(0.4, animations: {
            self.sliderMenu.alpha = 0
        }) { completed in
            if completed == true {
                self.sliderMenu.removeFromSuperview()
            }
        }
    }
    
    @IBOutlet var Share: UIButton!
    @IBAction func onShare(sender: AnyObject) {
        hideSecondaryMenu()
        hideSliderMenu()
        var image = imageView.image!
        if(Int(imageView.alpha) == 1) {
            image = imageView.image!
        }
        if(Int(filteredImage.alpha) == 1) {
            image = filteredImage.image!
        }
        let activityController = UIActivityViewController(activityItems: [image], applicationActivities: nil)
        presentViewController(activityController, animated: true, completion: nil)
    }
    
    @IBOutlet var changeSlider: UISlider!
    @IBAction func onSliderChange(sender: UISlider) {
        sliderValue = lroundf(changeSlider.value)
        if RedFilter.selected {
            onRedFilter(RedFilter)
        }
        if GreenFilter.selected {
            onGreenFilter(GreenFilter)
        }
        if BlueFilter.selected {
            onBlueFilter(BlueFilter)
        }
    }
    
    @IBOutlet var RedFilter: UIButton!
    @IBAction func onRedFilter(sender: UIButton) {
        originalLabel.alpha = 0.0
        let image = imageView.image!
        let filterimage = redConversion(image)
        filteredImage.image = filterimage
        UIView.animateWithDuration(0.4) {
            self.imageView.alpha = 0.0
            self.filteredImage.alpha = 1.0
        }
        RedFilter.selected = true
        Compare.enabled = true
        buttonEdit.enabled = true
        GreenFilter.selected = false
        BlueFilter.selected = false
    }
    func redConversion(image:UIImage) -> UIImage {
        let rgbaImage = RGBAImage(image: image)!
        for y in 0..<rgbaImage.height {
            for x in 0..<rgbaImage.width {
                let index = y * rgbaImage.width + x
                var pixel = rgbaImage.pixels[index]
                pixel.red = UInt8(min(255,Int(pixel.red) * sliderValue))
                rgbaImage.pixels[index] = pixel
            }
        }
        let filterimage = rgbaImage.toUIImage()
        return filterimage!
    }
    
    @IBOutlet var GreenFilter: UIButton!
    @IBAction func onGreenFilter(sender: UIButton) {
        originalLabel.alpha = 0.0
        let image = imageView.image!
        let filterimage = greenConversion(image)
        filteredImage.image = filterimage
        UIView.animateWithDuration(0.4) {
            self.imageView.alpha = 0.0
            self.filteredImage.alpha = 1.0
        }
        GreenFilter.selected = true
        Compare.enabled = true
        buttonEdit.enabled = true
        RedFilter.selected = false
        BlueFilter.selected = false
    }
    func greenConversion(image:UIImage) -> UIImage {
        let rgbaImage = RGBAImage(image: image)!
        for y in 0..<rgbaImage.height {
            for x in 0..<rgbaImage.width {
                let index = y * rgbaImage.width + x
                var pixel = rgbaImage.pixels[index]
                pixel.green = UInt8(min(255,Int(pixel.green) * sliderValue))
                rgbaImage.pixels[index] = pixel
            }
        }
        let filterimage = rgbaImage.toUIImage()
        return filterimage!
    }
    
    @IBOutlet var BlueFilter: UIButton!
    @IBAction func onBlueFilter(sender: UIButton) {
        originalLabel.alpha = 0.0
        let image = imageView.image!
        let filterimage = blueConversion(image)
        filteredImage.image = filterimage
        UIView.animateWithDuration(0.4) {
            self.imageView.alpha = 0.0
            self.filteredImage.alpha = 1.0
        }
        BlueFilter.selected = true
        Compare.enabled = true
        buttonEdit.enabled = true
        RedFilter.selected = false
        GreenFilter.selected = false
    }
    func blueConversion(image:UIImage) -> UIImage {
        let rgbaImage = RGBAImage(image: image)!
        for y in 0..<rgbaImage.height {
            for x in 0..<rgbaImage.width {
                let index = y * rgbaImage.width + x
                var pixel = rgbaImage.pixels[index]
                pixel.blue = UInt8(min(255,Int(pixel.blue) * sliderValue))
                rgbaImage.pixels[index] = pixel
            }
        }
        let filterimage = rgbaImage.toUIImage()
        return filterimage!
    }
    
    @IBOutlet var buttonOriginal: UIButton!
    @IBAction func onbuttonOriginal(sender: UIButton) {
        imageView.alpha = 1.0
        originalLabel.alpha = 1.0
        filteredImage.alpha = 0.0
        buttonEdit.enabled = false
        Compare.enabled = false
        RedFilter.selected = false
        BlueFilter.selected = false
        GreenFilter.selected = false
    }
    
    @IBOutlet var Compare: UIButton!
    @IBAction func onCompare(sender: UIButton) {
        if Compare.selected {
            UIView.animateWithDuration(1.0) {
                self.filteredImage.alpha = 1.0
                self.imageView.alpha = 0.0
                self.originalLabel.alpha = 0.0
            }
            Compare.selected = false
            buttonEdit.enabled = true
        } else {
            UIView.animateWithDuration(1.0) {
                self.imageView.alpha = 1.0
                self.filteredImage.alpha = 0.0
                self.originalLabel.alpha = 1.0
            }
            Compare.selected = true
            buttonEdit.enabled = false
            hideSecondaryMenu()
            hideSliderMenu()
            filterButton.selected = false
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        secondaryMenu.backgroundColor = UIColor.whiteColor().colorWithAlphaComponent(0.5)
        sliderMenu.backgroundColor = UIColor.whiteColor().colorWithAlphaComponent(0.5)
        secondaryMenu.translatesAutoresizingMaskIntoConstraints = false
        sliderMenu.translatesAutoresizingMaskIntoConstraints = false
        buttonEdit.enabled = false
        let image = UIImage(named: "backgroundimage")!
        imageView.image = image
        filteredImage.alpha = 0.0
        //avgColor(image)
        let tapGestureRecognizer = UILongPressGestureRecognizer(target: self, action: #selector(ViewController.imageToggle(_:)))
        imageView.userInteractionEnabled = true
        imageView.addGestureRecognizer(tapGestureRecognizer)
        filteredImage.userInteractionEnabled = true
        filteredImage.addGestureRecognizer(tapGestureRecognizer)
        originalLabel.alpha = 1.0
    }
    /*
    func avgColor(image:UIImage!) {
        let myRGBA = RGBAImage(image:image)!
        imageView.image = image
        Compare.enabled = false
        var totalRed = 0
        var totalGreen = 0
        var totalBlue = 0
        for y in 0..<myRGBA.height {
            for x in 0..<myRGBA.width {
                let index = y * myRGBA.width + x
                var pixel = myRGBA.pixels[index]
                totalRed += Int(pixel.red)
                totalGreen += Int(pixel.green)
                totalBlue += Int(pixel.blue)
            }
        }
        let count = myRGBA.width * myRGBA.height
        avgRed = Int(totalRed/count)
        avgGreen = Int(totalGreen/count)
        avgBlue = Int(totalBlue/count)
    }
    */
    func imageToggle(sender: UILongPressGestureRecognizer) {
        if sender.state == .Began{
                originalLabel.alpha = 1.0
                imageView.alpha = 1.0
                filteredImage.alpha = 0.0
        } else if sender.state == .Ended {
                originalLabel.alpha = 0.0
                filteredImage.alpha = 1.0
                imageView.alpha = 0.0
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}